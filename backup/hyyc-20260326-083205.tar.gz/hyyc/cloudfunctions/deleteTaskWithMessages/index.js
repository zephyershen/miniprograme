// 云函数：deleteTaskWithMessages
// 功能：删除指定任务以及该任务下所有聊天记录（文字 + 图片消息）。
// 说明：
// - 为了绕过小程序端数据库权限（例如“仅创建者可写”），删除操作统一放在云函数里执行。
// - 调用方必须是任务发布者本人，否则返回错误。

const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV,
});

const db = cloud.database();
const TASK_COLLECTION = 'tasks';
const MSG_COLLECTION = 'messages';
const USER_COLLECTION = 'userInfo';

function pickStr(v) {
  return String(v == null ? '' : v).trim();
}

function getLogicalUserId(user = {}) {
  return pickStr(user && user.id, user && user._id);
}

function canWorkerDeleteTaskRecord(task = {}) {
  const t = task && typeof task === 'object' ? task : {};
  const pay = t.pay && typeof t.pay === 'object' ? t.pay : {};
  const refund = pay.refund && typeof pay.refund === 'object' ? pay.refund : {};
  const status = pickStr(t.status);
  const payStatus = pickStr(pay.status);
  const refundStatus = pickStr(refund.status);
  return status === 'completed'
    || (status === 'cancelled' && (payStatus === 'refunded' || refundStatus === 'success'));
}

function resolveTaskDeleteState(task = {}) {
  const t = task && typeof task === 'object' ? task : {};
  const pay = t.pay && typeof t.pay === 'object' ? t.pay : {};
  const refund = pay.refund && typeof pay.refund === 'object' ? pay.refund : {};
  const split = t.split && typeof t.split === 'object' ? t.split : {};

  const status = pickStr(t.status);
  const payStatus = pickStr(pay.status);
  const refundStatus = pickStr(refund.status);
  const splitStatus = pickStr(split.status);

  const hasSettledPayment = !!(
    t.paidAt
    || ['paid', 'refund_pending', 'refunded'].includes(payStatus)
  );

  return {
    status,
    payStatus,
    canDeletePendingUnpaid: status === 'pay_pending' && !hasSettledPayment,
    canDeleteCompleted: status === 'completed' || splitStatus === 'completed' || !!t.completedAt,
    canDeleteRefundedCancelled: status === 'cancelled' && (payStatus === 'refunded' || refundStatus === 'success'),
    hasSettledPayment,
  };
}

exports.main = async (event, context) => {
  const { tid, mode: rawMode } = event || {};
  const mode = pickStr(rawMode);

  if (!tid) {
    return {
      ok: false,
      code: 'INVALID_PARAM',
      msg: '缺少任务 ID',
    };
  }

  try {
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID || wxContext.openId || '';

    if (!openid) {
      return {
        ok: false,
        code: 'NO_OPENID',
        msg: '获取用户身份失败',
      };
    }

    // 1）根据 openid 找到当前用户在 userInfo 集合里的实名记录
    const userRes = await db
      .collection(USER_COLLECTION)
      .where({ _openid: openid })
      .limit(2)
      .get();

    const list = (userRes && userRes.data) || [];

    if (list.length > 1) {
      return {
        ok: false,
        code: 'MULTI_USER',
        msg: '当前微信账号存在多条实名记录，请联系管理员处理',
      };
    }

    const me = list[0] || null;

    if (!me || !getLogicalUserId(me)) {
      return {
        ok: false,
        code: 'USER_NOT_FOUND',
        msg: '当前用户未完成实名，无法删除任务',
      };
    }

    const myUserId = getLogicalUserId(me);

    // 2）加载任务，按模式校验权限
    const taskRes = await db.collection(TASK_COLLECTION).doc(tid).get();
    const task = (taskRes && taskRes.data) || null;

    if (!task || !task._id) {
      return {
        ok: false,
        code: 'TASK_NOT_FOUND',
        msg: '任务不存在或已被删除',
      };
    }

    if (mode === 'worker_record') {
      if (!task.workerId || task.workerId !== myUserId) {
        return {
          ok: false,
          code: 'NOT_WORKER',
          msg: '只有接单人可以删除该任务记录',
        };
      }
      if (task.workerDeletedAt) {
        return {
          ok: true,
          code: 'OK',
          msg: '任务记录已删除',
          already: true,
          deletedTaskId: tid,
          deleteMode: 'worker_record',
        };
      }
      if (!canWorkerDeleteTaskRecord(task)) {
        return {
          ok: false,
          code: 'TASK_DELETE_FORBIDDEN',
          msg: '当前任务暂不支持删除记录',
        };
      }

      await db.collection(TASK_COLLECTION).doc(tid).update({
        data: {
          workerDeletedAt: new Date(),
          updatedAt: new Date(),
        }
      });

      return {
        ok: true,
        code: 'OK',
        msg: '任务记录已删除',
        deletedTaskId: tid,
        deleteMode: 'worker_record',
      };
    }

    if (!task.ownerId || task.ownerId !== myUserId) {
      return {
        ok: false,
        code: 'NOT_OWNER',
        msg: '只有任务发布者可以删除任务及相关聊天记录',
      };
    }

    const deleteState = resolveTaskDeleteState(task);
    if (
      !deleteState.canDeletePendingUnpaid
      && !deleteState.canDeleteCompleted
      && !deleteState.canDeleteRefundedCancelled
    ) {
      return {
        ok: false,
        code: deleteState.hasSettledPayment ? 'PAID_TASK_DELETE_FORBIDDEN' : 'TASK_DELETE_FORBIDDEN',
        msg: deleteState.hasSettledPayment
          ? '该任务已发起或完成支付，当前删除不会自动退款，已禁止删除。请先走退款/取消流程。'
          : '当前任务状态暂不允许删除。',
      };
    }

    // 3）分批删除该任务下的所有聊天记录（按 tid 过滤）
    const msgColl = db.collection(MSG_COLLECTION);
    const BATCH_LIMIT = 100; // 每批次最多处理 100 条，防止超出单次操作上限
    let deletedMessages = 0;

    // 使用循环 + 分批查询 + doc().remove() 的方式，确保权限和数量都可控
    // 注意：不要在 where().remove() 里一次性删太多，分批更安全。
    while (true) {
      const queryRes = await msgColl
        .where({ tid })
        .limit(BATCH_LIMIT)
        .get();

      const list = (queryRes && queryRes.data) || [];
      if (!list.length) {
        break;
      }

      // 并行删除本批次消息
      const removeTasks = list.map((doc) =>
        msgColl.doc(doc._id).remove()
      );
      await Promise.all(removeTasks);

      deletedMessages += list.length;

      if (list.length < BATCH_LIMIT) {
        // 本批次不足 BATCH_LIMIT，说明已经删完
        break;
      }
      // 如果正好等于 BATCH_LIMIT，再继续下一轮循环
    }

    // 4）删除任务本身
    await db.collection(TASK_COLLECTION).doc(tid).remove();

    return {
      ok: true,
      code: 'OK',
      msg: '任务及相关聊天记录已删除',
      deletedMessages,
      deletedTaskId: tid,
    };
  } catch (err) {
    console.error('deleteTaskWithMessages 执行失败', err);
    return {
      ok: false,
      code: err && err.errCode ? String(err.errCode) : 'DELETE_ERROR',
      msg: err && err.errMsg ? err.errMsg : '删除任务失败，请稍后重试',
    };
  }
};
